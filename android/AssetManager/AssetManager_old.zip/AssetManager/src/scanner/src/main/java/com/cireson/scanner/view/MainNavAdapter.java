package com.cireson.scanner.view;

import android.content.Context;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import com.cireson.scanner.R;
import com.cireson.scanner.model.NavUIModel;
import com.cireson.scanner.util.DynamicHeightImageView;
import com.cireson.scanner.util.DynamicHeightTextView;

/**
 * Created by Ravindra on 2/13/14.
 */
public class MainNavAdapter extends ArrayAdapter<NavUIModel> {

    private static String TAG = "MainNavAdapter";
    private final LayoutInflater layoutInflater;


    static class ViewHolder {
        DynamicHeightTextView textLine;
        DynamicHeightImageView imageView;
    }


    public MainNavAdapter(final Context context, final int resource) {
        super(context, resource);
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public void notifyDataSetChanged(){
        super.notifyDataSetChanged();
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        ViewHolder viewHolder;

        if(convertView == null) {
            convertView = layoutInflater.inflate(R.layout.main_nav_row, parent, false);
            viewHolder = new ViewHolder();

            viewHolder.imageView = (DynamicHeightImageView) convertView.findViewById(R.id.navImage);
            viewHolder.textLine = (DynamicHeightTextView) convertView.findViewById(R.id.navTextLine);

           convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.textLine.setText(getItem(position).getNavText());
        viewHolder.textLine.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16.0f);
        viewHolder.imageView.setImageDrawable(getItem(position).getNavImageDrawable());


        return convertView;
    }
}
