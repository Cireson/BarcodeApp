package com.cireson.scanner.model;

/**
 * Created by Ravindra on 2/16/14.
 */
public class ScanItemModel {

    private String scanItemText;
    private Boolean scanItemCheckbox;
    private Boolean showScanItemButton;

    public String getScanItemText(){
        return scanItemText;
    }

    public void setScanItemText(String value){
        scanItemText = value;
    }

    public Boolean getScanItemCheckbox(){
        return scanItemCheckbox;
    }

    public void setScanItemCheckbox(Boolean value){
        scanItemCheckbox = value;
    }

    public Boolean getShowScanItemButton(){
        return showScanItemButton;
    }

    public void setShowScanItemButton(Boolean value){
        showScanItemButton = value;
    }

}
