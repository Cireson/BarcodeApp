package com.cireson.scanner.view;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.cireson.scanner.R;
import com.cireson.scanner.util.CameraManager;
import com.cireson.scanner.util.CaptureHandler;
import com.cireson.scanner.util.PreviewCallback;


public class ScanActivity extends Activity {

    private CameraPreviewView cameraPreview;
    private CameraManager cameraManager;
    private CaptureHandler captureHandler;

    private static String TAG = "Cireson Scanner ScanActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        try{
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_scan);

            if (savedInstanceState == null) {
                getFragmentManager().beginTransaction()
                        .add(R.id.container, new PlaceholderFragment())
                        .commit();
            }

            // Create an instance of Camera
            cameraManager = new CameraManager();
            captureHandler = new CaptureHandler(cameraManager, this, new OnDecoded());
            //requesting next frame for decoding
            cameraManager.requestNextFrame(new PreviewCallback(captureHandler, cameraManager));

            // Create our Preview view and set it as the content of our activity.
            cameraPreview = (CameraPreviewView) findViewById(R.id.camera_preview);
            cameraPreview.setCameraManager(cameraManager);
            ((BoundingView) findViewById(R.id.bounding_view)).setCameraManager(cameraManager);
        }
        catch(Exception ex){
            Log.d(TAG, Log.getStackTraceString(ex));
        }

    }

    @Override
    protected void onPause() {
        super.onPause();
        cameraManager.release();
    }

    private class OnDecoded implements CaptureHandler.OnDecodedCallback {
        @Override
        public void onDecoded(String decodedData) {
            Toast.makeText(ScanActivity.this, decodedData, Toast.LENGTH_SHORT);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        
        // Inflate the menu; this adds items to the action bar if it is present.
        try{
            getMenuInflater().inflate(R.menu.scan, menu);
        }
        catch(Exception ex){
            Log.d(TAG, Log.getStackTraceString(ex));
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        try{
            int id = item.getItemId();
            if (id == R.id.action_settings) {
                return true;
            }
        }
        catch(Exception ex){
            Log.d(TAG, Log.getStackTraceString(ex));
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * A placeholder fragment containing a simple view.
     */
    public static class PlaceholderFragment extends Fragment {

        public PlaceholderFragment() {
        }

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
            View rootView = inflater.inflate(R.layout.fragment_scan, container, false);
            return rootView;
        }
    }

}
