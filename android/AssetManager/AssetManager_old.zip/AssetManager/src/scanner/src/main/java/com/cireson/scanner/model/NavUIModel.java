package com.cireson.scanner.model;

import android.graphics.drawable.Drawable;

/**
 * Created by Ravindra on 2/14/14.
 */
public class NavUIModel {

    private String navText;
    private Drawable navImageDrawable;

    public String getNavText(){
        return this.navText;
    }

    public void setNavText(String value){
        navText = value;
    }

    public Drawable getNavImageDrawable(){
        return this.navImageDrawable;
    }

    public void setNavImageDrawable(Drawable value){
        navImageDrawable = value;
    }
}
