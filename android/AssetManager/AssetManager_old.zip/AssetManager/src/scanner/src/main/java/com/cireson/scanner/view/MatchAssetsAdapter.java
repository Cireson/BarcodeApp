package com.cireson.scanner.view;

import android.content.Context;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import com.cireson.scanner.R;
import com.cireson.scanner.model.ScanItemModel;


/**
 * Created by Ravindra on 2/17/14.
 */
public class MatchAssetsAdapter extends ArrayAdapter<ScanItemModel> {

    private static String TAG = "MatchAssetsAdapter";
    private final LayoutInflater layoutInflater;

    static class ViewHolder {
        TextView textView;
        CheckBox checkBoxView;
        Button buttonView;
    }

    public MatchAssetsAdapter(final Context context, final int resource) {
        super(context, resource);
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public void notifyDataSetChanged(){
        super.notifyDataSetChanged();
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        ViewHolder viewHolder;

        if(convertView == null) {
            convertView = layoutInflater.inflate(R.layout.matched_assets_row, parent, false);
            viewHolder = new ViewHolder();

            viewHolder.textView = (TextView) convertView.findViewById(R.id.matched_asset_item_number);
            viewHolder.checkBoxView = (CheckBox) convertView.findViewById(R.id.matched_asset_item_check_box);
            viewHolder.buttonView = (Button) convertView.findViewById(R.id.matched_asset_item_button);

            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder) convertView.getTag();
        }
        viewHolder.textView.setText(getItem(position).getScanItemText());
        viewHolder.textView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 16.0f);

        viewHolder.checkBoxView.setChecked(getItem(position).getScanItemCheckbox());

        if(getItem(position).getShowScanItemButton()){
            viewHolder.buttonView.setVisibility(View.VISIBLE);
        }else {
            viewHolder.buttonView.setVisibility(View.INVISIBLE);
        }

        return convertView;
    }
}
