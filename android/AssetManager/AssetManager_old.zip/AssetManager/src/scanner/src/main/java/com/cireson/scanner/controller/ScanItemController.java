package com.cireson.scanner.controller;

import com.cireson.scanner.model.ScanItemModel;

import java.util.ArrayList;

/**
 * Created by Ravindra on 2/17/14.
 */
public class ScanItemController {

    private static ArrayList<ScanItemModel> modelItems;

    public ScanItemController(){
        if (modelItems == null){
            modelItems = new ArrayList<ScanItemModel>();
        }
    }

    public String getScanItemText(int index){
        return modelItems.get(index).getScanItemText();
    }

    public void setScanItemText(int index, String value){
        modelItems.get(index).setScanItemText(value);
    }

    public Boolean getScanItemCheckbox(int index){
        return modelItems.get(index).getScanItemCheckbox();
    }

    public void setScanItemCheckbox(int index, Boolean value){
        modelItems.get(index).setScanItemCheckbox(value);
    }

    public Boolean getShowScanItemButton(int index){
        return modelItems.get(index).getShowScanItemButton();
    }

    public void setShowScanItemButton(int index, Boolean value){
        modelItems.get(index).setShowScanItemButton(value);
    }

    public ArrayList<ScanItemModel> getItems(){
        return this.modelItems;
    }

    public void add(ScanItemModel item){
        this.modelItems.add(item);
    }

    public boolean containsItem(String text){
        for (ScanItemModel data : modelItems) {
            if(data.getScanItemText().toString().toLowerCase().trim() == text.toLowerCase().trim()){
                return true;
            }
        }
        return false;
    }
}
