package com.cireson.scanner.controller;

import android.graphics.drawable.Drawable;

import com.cireson.scanner.model.NavUIModel;

import java.util.ArrayList;

/**
 * Created by Ravindra on 2/17/14.
 */
public class NavUIController {

    private NavUIModel model = new NavUIModel();
    // private ArrayList<NavUIModel> navigationItems = new ArrayList();

    public String getNavText(){
        return this.model.getNavText();
    }

    public void setNavText(String value){
        this.model.setNavText(value);
    }

    public Drawable getNavImageDrawable(){
        return this.model.getNavImageDrawable();
    }

    public void setNavImageDrawable(Drawable value){
        this.model.setNavImageDrawable(value);
    }
}
